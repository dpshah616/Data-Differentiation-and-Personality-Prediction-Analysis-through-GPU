﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace personality_prediction_GPU_277
{
    public partial class MDIParent1 : Form
    {
        private int childFormNumber = 0;

        public MDIParent1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void uploadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            upload_dataset u = new upload_dataset();
            u.Show();
        }

        private void naiveTestingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            naive_training n = new naive_training();
            n.Show();
        }

       
    }
}
